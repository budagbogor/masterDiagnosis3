import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/diagnosis/[id] - Get specific diagnosis
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const diagnosis = await db.diagnosis.findUnique({
      where: { id }
    })

    if (!diagnosis) {
      return NextResponse.json(
        { success: false, error: 'Diagnosis not found' },
        { status: 404 }
      )
    }

    // Parse JSON fields
    const parsedDiagnosis = {
      ...diagnosis,
      sounds: JSON.parse(diagnosis.sounds || '[]'),
      vibrations: JSON.parse(diagnosis.vibrations || '[]'),
      smells: JSON.parse(diagnosis.smells || '[]'),
      warningLights: JSON.parse(diagnosis.warningLights || '[]'),
      conditions: JSON.parse(diagnosis.conditions || '[]'),
      partsReplaced: JSON.parse(diagnosis.partsReplaced || '[]'),
      modifications: JSON.parse(diagnosis.modifications || '[]'),
      deepDiveData: JSON.parse(diagnosis.deepDiveData || '{}'),
      aiAnalysis: JSON.parse(diagnosis.aiAnalysis || '{}')
    }

    return NextResponse.json({
      success: true,
      data: parsedDiagnosis
    })
  } catch (error) {
    console.error('Error fetching diagnosis:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch diagnosis' },
      { status: 500 }
    )
  }
}
