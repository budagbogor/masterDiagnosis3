import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

// GET /api/diagnosis - Get all diagnosis history
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '50')
    const offset = parseInt(searchParams.get('offset') || '0')
    const brand = searchParams.get('brand')
    const status = searchParams.get('status')

    const where: any = {}
    if (brand) where.brand = brand
    if (status) where.status = status

    const diagnoses = await db.diagnosis.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset
    })

    const total = await db.diagnosis.count({ where })

    return NextResponse.json({
      success: true,
      data: diagnoses,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    })
  } catch (error) {
    console.error('Error fetching diagnoses:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch diagnoses' },
      { status: 500 }
    )
  }
}

// POST /api/diagnosis - Create new diagnosis and analyze with AI
export async function POST(request: NextRequest) {
  let zai = null

  try {
    const body = await request.json()

    const {
      vehicle,
      symptoms,
      serviceHistory,
      initialChecks,
      deepDive
    } = body

    // Validate required fields
    if (!vehicle?.brand || !vehicle?.model || !vehicle?.year || !vehicle?.engineCode) {
      return NextResponse.json(
        { success: false, error: 'Missing required vehicle information' },
        { status: 400 }
      )
    }

    if (!symptoms?.complaint) {
      return NextResponse.json(
        { success: false, error: 'Missing complaint description' },
        { status: 400 }
      )
    }

    // Create diagnosis record first
    const diagnosis = await db.diagnosis.create({
      data: {
        vin: vehicle.vin,
        brand: vehicle.brand,
        model: vehicle.model,
        year: vehicle.year,
        engineCode: vehicle.engineCode,
        transmission: vehicle.transmission,
        mileage: parseInt(vehicle.mileage) || 0,
        complaint: symptoms.complaint,
        sounds: JSON.stringify(symptoms.sounds || []),
        vibrations: JSON.stringify(symptoms.vibrations || []),
        smells: JSON.stringify(symptoms.smells || []),
        warningLights: JSON.stringify(symptoms.warningLights || []),
        conditions: JSON.stringify(symptoms.conditions || []),
        additionalNotes: symptoms.additionalNotes,
        lastServiceDate: serviceHistory?.lastServiceDate,
        partsReplaced: JSON.stringify(serviceHistory?.partsReplaced || []),
        modifications: JSON.stringify(serviceHistory?.modifications || []),
        errorCodes: initialChecks?.errorCodes,
        visualInspection: initialChecks?.visualInspection,
        testDriveNotes: initialChecks?.testDriveNotes,
        deepDiveData: JSON.stringify(deepDive || {}),
        status: 'analyzing'
      }
    })

    // Analyze with LLM (Master Teknisi Otomotif AI)
    zai = await ZAI.create()

    const systemPrompt = `You are a Master Automotive Technician with 20+ years of experience working at:
- Japanese dealerships (Toyota, Honda, Mitsubishi, Suzuki)
- European luxury dealerships (Mercedes-Benz, BMW, Audi, VW)
- Korean brands (Hyundai, Kia)
- Performance tuning shops (APR, HKS, Spoon Sports)

Your expertise includes:
- All automotive systems (engine, transmission, electrical, suspension, brakes, HVAC)
- Common failure patterns across different brands and climates (especially tropical climates like Indonesia)
- Dealer service bulletins and technical recalls
- Aftermarket modifications and their impact on reliability
- Modern diagnostic tools (OBD-II scanners, oscilloscopes, pressure gauges)

ANALYSIS REQUIREMENTS:
1. Think systematically like a professional mechanic
2. Consider the most common failures first (80/20 rule)
3. Account for mileage, climate, and service history
4. Provide actionable, practical solutions
5. Reference real-world technical knowledge from manuals, TSBs, and field experience

OUTPUT FORMAT (respond in JSON):
{
  "summary": "Brief overview of the diagnosis",
  "possibleCauses": [
    {
      "title": "Name of the suspected component/system",
      "probability": "Very High (80-100%) | High (50-79%) | Moderate (30-49%) | Low (10-29%)",
      "reasoning": "Why this cause fits the symptoms",
      "symptomsMatch": "Which symptoms align with this cause",
      "verificationSteps": ["Step 1...", "Step 2..."],
      "estimatedCost": "Parts + labor estimate (if applicable)",
      "severity": "Critical | High | Medium | Low"
    }
  ],
  "recommendedChecks": [
    {
      "title": "Check name",
      "description": "What to check and why",
      "tools": ["Tool 1", "Tool 2"],
      "expectedValues": "Normal values to look for"
    }
  ],
  "safetyWarnings": ["Warning 1...", "Warning 2..."],
  "commonMistakes": ["Mistake 1...", "Mistake 2..."],
  "technicalExplanation": {
    "howItWorks": "Brief technical explanation of the related system",
    "whySymptomsOccur": "Why these symptoms are happening"
  }
}

IMPORTANT:
- Prioritize causes based on probability from real-world data
- Be specific about verification steps (include pressure values, resistance ranges, etc.)
- Consider the vehicle's age and mileage
- Flag any safety-critical issues immediately
- Reference brand-specific tendencies where applicable
- Account for the tropical climate of Indonesia if relevant`

    // Build prompt with all diagnosis data
    const userPrompt = `Analyze this vehicle issue as a Master Technician:

**VEHICLE INFO:**
- Brand: ${vehicle.brand} ${vehicle.model}
- Year: ${vehicle.year}
- Engine Code: ${vehicle.engineCode}
- Transmission: ${vehicle.transmission}
- Mileage: ${vehicle.mileage} km
- VIN: ${vehicle.vin || 'Not provided'}

**CUSTOMER COMPLAINT:**
${symptoms.complaint}

**SYMPTOMS:**
- Sounds: ${symptoms.sounds?.join(', ') || 'None reported'}
- Vibrations: ${symptoms.vibrations?.join(', ') || 'None reported'}
- Smells: ${symptoms.smells?.join(', ') || 'None reported'}
- Warning Lights: ${symptoms.warningLights?.join(', ') || 'None'}
- Conditions: ${symptoms.conditions?.join(', ') || 'None reported'}
- Additional Notes: ${symptoms.additionalNotes || 'None'}

**SERVICE HISTORY:**
- Last Service: ${serviceHistory?.lastServiceDate || 'Unknown'}
- Parts Recently Replaced: ${serviceHistory?.partsReplaced?.join(', ') || 'None reported'}
- Modifications: ${serviceHistory?.modifications?.join(', ') || 'None reported'}

**INITIAL CHECKS:**
- OBD Error Codes: ${initialChecks?.errorCodes || 'None'}
- Visual Inspection: ${initialChecks?.visualInspection || 'None'}
- Test Drive Notes: ${initialChecks?.testDriveNotes || 'None'}

**ADDITIONAL DATA:**
${deepDive ? JSON.stringify(deepDive, null, 2) : 'No additional data'}

Provide a detailed analysis following the format specified in the system prompt. Be thorough, practical, and base your recommendations on real-world automotive service experience.`

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      thinking: { type: 'disabled' }
    })

    const aiResponse = completion.choices[0]?.message?.content

    if (!aiResponse) {
      throw new Error('No response from AI')
    }

    // Parse AI response
    let analysisResult
    try {
      // Try to extract JSON from response
      const jsonMatch = aiResponse.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0])
      } else {
        // Fallback if JSON parsing fails
        analysisResult = {
          summary: aiResponse,
          possibleCauses: [],
          recommendedChecks: [],
          safetyWarnings: [],
          commonMistakes: [],
          technicalExplanation: {
            howItWorks: '',
            whySymptomsOccur: ''
          }
        }
      }
    } catch (e) {
      console.error('Error parsing AI response:', e)
      analysisResult = {
        summary: aiResponse,
        possibleCauses: [],
        recommendedChecks: [],
        safetyWarnings: [],
        commonMistakes: [],
        technicalExplanation: {
          howItWorks: '',
          whySymptomsOccur: ''
        }
      }
    }

    // Update diagnosis with AI analysis result
    const updatedDiagnosis = await db.diagnosis.update({
      where: { id: diagnosis.id },
      data: {
        aiAnalysis: JSON.stringify(analysisResult),
        status: 'completed'
      }
    })

    return NextResponse.json({
      success: true,
      data: updatedDiagnosis,
      analysis: analysisResult
    })
  } catch (error) {
    console.error('Error creating diagnosis:', error)

    // Try to update status to error if diagnosis was created
    try {
      if (request.body) {
        // Find the most recent diagnosis for this vehicle and update status
        const recentDiagnosis = await db.diagnosis.findFirst({
          where: { status: 'analyzing' },
          orderBy: { createdAt: 'desc' }
        })
        if (recentDiagnosis) {
          await db.diagnosis.update({
            where: { id: recentDiagnosis.id },
            data: { status: 'error' }
          })
        }
      }
    } catch (e) {
      // Ignore update error
    }

    return NextResponse.json(
      { success: false, error: error.message || 'Failed to create diagnosis' },
      { status: 500 }
    )
  }
}
