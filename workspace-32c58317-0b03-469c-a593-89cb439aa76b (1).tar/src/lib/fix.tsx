      'Clean atau ganti MAF sensor',
      'Cek O2 sensor response',
    ],
    estimatedCost: 'Rp 300.000 - 1.500.000',
    referenceSource: ['OBD-II Codes', 'Haynes Repair Manual']
  },